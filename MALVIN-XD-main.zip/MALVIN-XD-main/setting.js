//=====🏅 ᴍᴀʟᴠɪɴ  xᴅ🔥====

module.exports = {
  BOT_NAME: 'ᴍᴀʟᴠɪɴ xᴅ', // ur bot name
  OWNER_NAME: 'ᴍᴀʟᴠɪɴ ᴋɪɴɢ', //your name
  OWNER_NUMBER: '263714757857', // add your phone number
  SESSION_ID: '', // add your session ID
  MODE: "public", // public or private
  TIMEZONE: 'Africa/Harare' // ur timezone
};
